#!/usr/bin/env python
#-*- coding:utf-8 -*-

from scipy import sparse

import numpy as np
import pandas as pd

class Pandas02Final(object):
    """计算物品推荐数据"""

    def __init__(self):
        self.goods_dict = {}
        self.user_dict = {}
        self.goods_bought_count_matrix = None
        self.user_goods_score_matrix = None
        self.every_user_goods_score_matrix = None
        self.every_user_goods_score_df = None
      

    def get_goods_dict(self, file_name):
        """通过读取文件从而获得商品字典"""
        with open(file_name) as f:
            for index, line in enumerate(f):
                items = line.split('"')
                goods = items[1]
                self.goods_dict[goods] = index

    def get_user_dict(self, file_name):
        """通过读取文件从而获得用户字典"""
        with open(file_name) as f:
            for index, line in enumerate(f):
                items = line.split('"')
                user = items[1]
                self.user_dict[user] = index

    def get_goods_bought_count_matrix(self, file_name):
        """获得商品购买次数矩阵"""
        # 定义稀疏矩阵的行, 列, 值
        row_indices = [] # 行是商品
        col_indices = [] # 列是商品
        values = [] # 值是 1
        
        with open(file_name) as f:
            for line in f:
                # 获得 用户 商品:评分,商品:评分...
                items = line.split('"') 
                goods_scores = items[3]
                for goods_score in goods_scores.split(','):
                    goods_row = goods_score.split(':')[0] # 获得行的商品
                    for goods_score in goods_scores.split(','):
                        goods_col = goods_score.split(':')[0] # 获得列的商品
                        # 添加矩阵的 行 列 值
                        row_indices.append(self.goods_dict[goods_row]) # 使用 goods_dict 的值代替
                        col_indices.append(self.goods_dict[goods_col]) # 使用 goods_dict 的值代替
                        values.append(1) # 值为1

        # row_indices col_indices values 这三个变量中的值满足了稀疏矩阵的值,
        # 通过这三个变量构造矩阵
        row_indices = np.array(row_indices)
        col_indices = np.array(col_indices)
        values = np.array(values)

        # 生成矩阵(同现矩阵)
        self.goods_bought_count_matrix = sparse.coo_matrix(
                                             (values, (row_indices, col_indices)),
                                             shape = (len(self.goods_dict), len(self.goods_dict))
                                         ).todense()

    def get_user_goods_score_matrix(self, file_name):
        """获得用户商品评分矩阵(仅仅是用户购买购买过的商品)"""
        # 定义稀疏矩阵的行, 列, 值
        row_indices = [] # 行是商品
        col_indices = [] # 列是用户
        values = [] # 值是用户对商品的评分(score) 

        with open(file_name) as f:
            for line in f:
                user, goods, score = line.split(',')
                # 添加矩阵的 行 列 值
                row_indices.append(self.goods_dict[goods]) # 使用 goods_dict 的值代替
                col_indices.append(self.user_dict[user]) # 使用 user_dict 的值代替
                values.append(float(score)) # 值为用户评分(score)
                
        # row_indices col_indices values 这三个变量中的值满足了稀疏矩阵的值,
        # 通过这三个变量构造矩阵
        row_indices = np.array(row_indices)
        col_indices = np.array(col_indices)
        values = np.array(values)

        # 生成矩阵(同现矩阵)
        self.user_goods_score_matrix = sparse.coo_matrix(
                                             (values, (row_indices, col_indices)),
                                             shape = (len(self.goods_dict), len(self.user_dict))
                                         ).todense()

    def get_every_user_goods_score_matrix(self):
        """获得每个用户每个商品的评分情况
        计算公式: <商品购买次数矩阵> X <用户商品评分矩阵>
        """
        self.every_user_goods_score_matrix = (
                                  self.goods_bought_count_matrix
                                  *
                                  self.user_goods_score_matrix)

    def get_every_user_goods_score_df(self):
        """<每个用户每个商品评分矩阵> 和 Pandas, goods_dict, user_dict 结合获得最终的数据"""
        self.every_user_goods_score_df = pd.DataFrame(
                                     self.every_user_goods_score_matrix,
                                     columns = sorted(self.user_dict), # 用户为列
                                     index = sorted(self.goods_dict)) # 商品为索引


def main():
    pandas_02_final = Pandas02Final()

    # 1. 获得商品数据字典
    pandas_02_final.get_goods_dict('pandas_01_goods.data')
    print '=============================================='
    print '1. 获得商品数据字典'
    print '=============================================='
    print pandas_02_final.goods_dict

    # 2. 获得用户数据字典
    pandas_02_final.get_user_dict('pandas_01_user.data')
    print '=============================================='
    print '2. 获得用户数据字典'
    print '=============================================='
    print pandas_02_final.user_dict

    # 3. 获得商品购买次数矩阵
    pandas_02_final.get_goods_bought_count_matrix('02_user_goods_score_record.data')
    print '=============================================='
    print '3. 获得商品购买次数矩阵'
    print '=============================================='
    print pandas_02_final.goods_bought_count_matrix

    # 4. 获得用户商品评分矩矩阵(仅仅包含用户买过的商品)
    pandas_02_final.get_user_goods_score_matrix('01_user_goods_score.data')
    print '=============================================='
    print '4. 获得用户商品评分矩矩阵(仅仅包含用户买过的商品)'
    print '=============================================='
    print pandas_02_final.user_goods_score_matrix

    # 5. 两个矩阵相乘获得最终的 <每个用户每个商品评分矩阵>
    pandas_02_final.get_every_user_goods_score_matrix()
    print '=============================================='
    print '5. 两个矩阵相乘获得最终的 <每个用户每个商品评分矩阵>'
    print '=============================================='
    print pandas_02_final.every_user_goods_score_matrix

    # 6. <每个用户每个商品评分矩阵> 和 Pandas, goods_dict, user_dict 结合获得最终的数据
    pandas_02_final.get_every_user_goods_score_df()
    print '=============================================='
    print '6. <每个用户每个商品评分矩阵> 和 Pandas, goods_dict, user_dict 结合获得最终的数据'
    print '=============================================='
    print pandas_02_final.every_user_goods_score_df


if __name__ == '__main__':
    main()
