#!/usr/bin/env python
# -*- coding: utf-8 -*-

from mrjob.job import MRJob

class UserGoodsScore(MRJob):
    """获得用户购买的商品与评分记录"""

    def mapper(self, _, line):
        # 解析行: 用户, 商品, 评分
        user, goods, score = line.split(',')
        # 输出串: 商品:评分
        output = '{goods}:{score}'.format(goods = goods,
                                          score = score)
        yield user, output

    def reducer(self, key, values):
        yield key, ','.join(values)


def main():
    UserGoodsScore.run()

if __name__ == '__main__':
    main()
