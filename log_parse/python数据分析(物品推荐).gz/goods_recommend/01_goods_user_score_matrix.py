#!/usr/bin/env python
# -*- coding: utf-8 -*-

from mrjob.job import MRJob

class GoodsUserScoreMatrix(MRJob):
    """商品用户评分矩阵"""

    def mapper(self, _, line):
        # 解析行: 用户, 商品, 评分
        user, goods, score = line.split(',')
        # 输出串: 商品:评分
        output = '{user}:{score}'.format(user = user,
                                         score = score)
        yield goods, output

    def reducer(self, key, values):
        for value in values:
            yield key, value


def main():
    GoodsUserScoreMatrix.run()

if __name__ == '__main__':
    main()
