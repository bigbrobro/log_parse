#!/usr/bin/env python
# -*- coding: utf-8 -*-

from mrjob.job import MRJob

import os

class Matrix(MRJob):

    flag = None # 用于标记数据是哪个矩阵来的
    goods_ids = [101, 102, 103, 104, 105, 106, 107] # 矩阵A的商品ID
    user_ids = ['user1', 'user2', 'user3', 'user4', 'user5'] # 矩阵B 用户ID

    def mapper(self, _, line):
        file_name = os.environ['mapreduce_map_input_file']

        if file_name == '03_goods_bought_count_matrix.data': # 商品购买次数同现矩阵
            # 获得数组 矩阵
            item_i, item_j, item_value = self._get_matrix_item_1(line)

            for user_id in self.user_ids:
                # 获取key
                key = '{user_id},{item_i}'.format(item_i = item_i,
                                                  user_id = user_id)
                value = 'a,{item_j},{item_value}'.format(
                                            item_j = item_j,
                                            item_value = item_value)
                value = ['a', item_j, item_value]
                yield key, value
            
        elif file_name == '03_goods_user_score_matrix.data': # 商品用户评分矩阵
            # 获得数组 矩阵
            item_i, item_j, item_value = self._get_matrix_item_2(line)

            for goods_id in self.goods_ids:
                # 获取key
                key = '{item_j},{goods_id}'.format(goods_id = goods_id,
                                            item_j = item_j)
                value = 'b,{item_i},{item_value}'.format(
                                            item_i = item_i,
                                            item_value = item_value)
                value = ['b', item_i, item_value]
                yield key, value

    def reducer(self, key, values):
        goods_score = {}
        user_score = {}
        for flag, goods_id, value in values:
            if flag == 'a':
                goods_score[goods_id] = value
            elif flag == 'b':
                user_score[goods_id] = value
        # 计算有相同 goods_id 乘积之和
        sum = 0
        for goods_id in set(goods_score) & set(user_score):
            sum += float(goods_score[goods_id]) * float(user_score[goods_id])

        yield key, sum

    def _get_matrix_item_1(self, line):
        """解析03_goods_bought_count_matrix.data
           从而获得商品购买次数同现矩阵中的每个元素
           Args:
               line: "101:102"       3
           Return:
               item_i: 101
               item_j: 102
               value: 3
        """
        items = line.split('"')
        item_i, item_j = items[1].split(':')
        value = items[2].strip()
        return item_i, item_j, value
        

    def _get_matrix_item_2(self, line):
        """解析03_goods_user_score_matrix.data
           从而获得商品用户评分(只包含有买过的)矩阵中的每个元素
           Args:
               line: "107"   "user3:5.0"
           Return:
               item_i: 107
               item_j: user3
               value: 5.0
        """
        items = line.split('"')
        item_i = items[1]
        item_j, value = items[3].split(':')
        return item_i, item_j, value


def main():
    Matrix.run()

if __name__ == '__main__':
    main()
