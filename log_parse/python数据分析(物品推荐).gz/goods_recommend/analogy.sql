CREATE TABLE user_goods_score(
    user_goods_score_id INT NOT NULL AUTO_INCREMENT COMMENT 'ID',
    user_name VARCHAR(10) NOT NULL DEFAULT '' COMMENT '用户名',
    goods_id INT NOT NULL DEFAULT 0 COMMENT '商品ID',
    score DECIMAL(5, 2) NOT NULL DEFAULT 0.00 COMMENT '评分',
    PRIMARY KEY(user_goods_score_id)
)COMMENT = '用户商品评分';

INSERT INTO user_goods_score VALUES(NULL, 'user1',101,5.0);
INSERT INTO user_goods_score VALUES(NULL, 'user1',102,3.0);
INSERT INTO user_goods_score VALUES(NULL, 'user1',103,2.5);
INSERT INTO user_goods_score VALUES(NULL, 'user2',101,2.0);
INSERT INTO user_goods_score VALUES(NULL, 'user2',102,2.5);
INSERT INTO user_goods_score VALUES(NULL, 'user2',103,5.0);
INSERT INTO user_goods_score VALUES(NULL, 'user2',104,2.0);
INSERT INTO user_goods_score VALUES(NULL, 'user3',101,2.0);
INSERT INTO user_goods_score VALUES(NULL, 'user3',104,4.0);
INSERT INTO user_goods_score VALUES(NULL, 'user3',105,4.5);
INSERT INTO user_goods_score VALUES(NULL, 'user3',107,5.0);
INSERT INTO user_goods_score VALUES(NULL, 'user4',101,5.0);
INSERT INTO user_goods_score VALUES(NULL, 'user4',103,3.0);
INSERT INTO user_goods_score VALUES(NULL, 'user4',104,4.5);
INSERT INTO user_goods_score VALUES(NULL, 'user4',106,4.0);
INSERT INTO user_goods_score VALUES(NULL, 'user5',101,4.0);
INSERT INTO user_goods_score VALUES(NULL, 'user5',102,3.0);
INSERT INTO user_goods_score VALUES(NULL, 'user5',103,2.0);
INSERT INTO user_goods_score VALUES(NULL, 'user5',104,4.0);
INSERT INTO user_goods_score VALUES(NULL, 'user5',105,3.5);
INSERT INTO user_goods_score VALUES(NULL, 'user5',106,4.0);

SELECT user_name,
    GROUP_CONCAT(goods_id, ':', score)
FROM user_goods_score
GROUP BY user_name;
+-----------+-------------------------------------------------------+
| user_name | GROUP_CONCAT(goods_id, ':', score)                    |
+-----------+-------------------------------------------------------+
| user1     | 102:3.00,103:2.50,101:5.00                            |
| user2     | 101:2.00,102:2.50,103:5.00,104:2.00                   |
| user3     | 107:5.00,105:4.50,104:4.00,101:2.00                   |
| user4     | 101:5.00,103:3.00,104:4.50,106:4.00                   |
| user5     | 101:4.00,102:3.00,103:2.00,104:4.00,105:3.50,106:4.00 |
+-----------+-------------------------------------------------------+
