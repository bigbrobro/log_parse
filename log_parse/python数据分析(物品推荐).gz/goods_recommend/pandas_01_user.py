#!/usr/bin/env python
# -*- coding: utf-8 -*-

from mrjob.job import MRJob

class Pandas01GoodsIndex(MRJob):
    """商品用户评分矩阵"""

    def mapper(self, _, line):
        # 解析行: 用户, 商品, 评分
        user, goods, score = line.split(',')
        yield user, None

    def reducer(self, key, values):
        yield key, 1


def main():
    Pandas01GoodsIndex.run()

if __name__ == '__main__':
    main()
