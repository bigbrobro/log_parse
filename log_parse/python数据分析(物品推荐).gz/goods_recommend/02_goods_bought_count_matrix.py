#!/usr/bin/env python
# -*- coding: utf-8 -*-

from mrjob.job import MRJob

class GoodsBoughtCountMatrix(MRJob):
    """获得商品购买次数的同现矩阵"""

    def mapper(self, _, line):
        # 解析行
        tokens = line.split('"')
        user = tokens[1] # 获得用户, 如: 1
        score_matrix = tokens[3] # 评分矩阵, 如: 101:5.0,102:3.0,103:2.5
        # 获得物品 列表
        goods_score_list = score_matrix.split(',') # 获得商品得分列表
        # 获得商品列表
        goods_list = [goods_socre.split(':')[0] for goods_socre in goods_score_list]

        # 获得商品同现矩阵
        for goods1 in goods_list:
            for goods2 in goods_list:
                matrix_item = '{goods1}:{goods2}'.format(goods1 = goods1,
                                                         goods2 = goods2)
                yield matrix_item, 1

    def reducer(self, key, values):
        yield key, sum(values)


def main():
    GoodsBoughtCountMatrix.run()

if __name__ == '__main__':
    main()
